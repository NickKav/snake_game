package snake;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;
import javax.swing.Timer;

import javax.swing.JPanel;

public class GamePanel extends JPanel implements ActionListener{
	
	// 1. Ρυθμίσεις Οθόνης
    static final int SCREEN_WIDTH = 600;
    static final int SCREEN_HEIGHT = 600;
    static final int UNIT_SIZE = 25; // Πόσο μεγάλο είναι το κάθε τετραγωνάκι
    static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / UNIT_SIZE;
    static final int DELAY = 150; // Ταχύτητα (όσο μικρότερο, τόσο πιο γρήγορο)
    
 // 2. Συντεταγμένες Φιδιού & Μήλου
    final int x[] = new int[GAME_UNITS]; // x θέσεις σώματος
    final int y[] = new int[GAME_UNITS]; // y θέσεις σώματος
    int bodyParts = 6; // Αρχικό μέγεθος
    int applesEaten;
    int appleX;
    int appleY;

    char direction = 'R'; // R = Right, L = Left, U = Up, D = Down
    boolean running = false;
    Timer timer;
    Random random;

    GamePanel() {
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());
        startGame();
    }
    
    public void startGame() {
    	newApple();
    	running  =  true;
    	timer = new Timer(DELAY, this);
    	timer.start();
    }

	public void newApple() {
		//random thesi miloy
		appleX = random.nextInt((int)(SCREEN_WIDTH/UNIT_SIZE))*UNIT_SIZE;
		appleY = random.nextInt((int)(SCREEN_HEIGHT/UNIT_SIZE))*UNIT_SIZE;
		
	}
	public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        // Εδώ θα σχεδιάσουμε το φίδι και το μήλο στο επόμενο βήμα
    	if (running) {
            // Σχεδίαση Μήλου
            g.setColor(Color.red);
            g.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);

            // Σχεδίαση Φιδιού
            for (int i = 0; i < bodyParts; i++) {
                if (i == 0) { // Κεφάλι
                    g.setColor(Color.green);
                    g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                } else { // Σώμα
                    g.setColor(new Color(45, 180, 0));
                    g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
        } else {
            gameOver(g);
        }
    }
    
    public void gameOver(Graphics g) {
    	// Κείμενο Σκορ
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free", Font.BOLD, 40));
        FontMetrics metrics1 = getFontMetrics(g.getFont());
        g.drawString("Score: " + applesEaten, (SCREEN_WIDTH - metrics1.stringWidth("Score: " + applesEaten)) / 2, g.getFont().getSize());

        // Κείμενο Game Over
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free", Font.BOLD, 75));
        FontMetrics metrics2 = getFontMetrics(g.getFont());
        g.drawString("Game Over", (SCREEN_WIDTH - metrics2.stringWidth("Game Over")) / 2, SCREEN_HEIGHT / 2);
		
	}

	public void move() {
        // Μετακίνηση των τμημάτων του σώματος
        for (int i = bodyParts; i > 0; i--) {
            x[i] = x[i - 1];
            y[i] = y[i - 1];
        }

        // Μετακίνηση του κεφαλιού ανάλογα με την κατεύθυνση
        switch (direction) {
            case 'U': y[0] = y[0] - UNIT_SIZE; break; // Πάνω
            case 'D': y[0] = y[0] + UNIT_SIZE; break; // Κάτω
            case 'L': x[0] = x[0] - UNIT_SIZE; break; // Αριστερά
            case 'R': x[0] = x[0] + UNIT_SIZE; break; // Δεξιά
        }
    }
    
    public void checkApple() {
        if ((x[0] == appleX) && (y[0] == appleY)) {
            bodyParts++;
            applesEaten++;
            newApple();
        }
    }
    public void checkCollisions() {
        // Έλεγχος αν το κεφάλι τράκαρε με το σώμα
        for (int i = bodyParts; i > 0; i--) {
            if ((x[0] == x[i]) && (y[0] == y[i])) {
                running = false;
            }
        }
        if (x[0] < 0 || x[0] >= SCREEN_WIDTH || y[0] < 0 || y[0] >= SCREEN_HEIGHT) {
            running = false;
        }

        if (!running) {
            timer.stop();
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // Αυτό καλείται σε κάθε "τικ" του Timer
    	if(running) {
    		move();
    		checkApple();
    		checkCollisions();
    	}
    	repaint();
    }

    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            // Εδώ θα ελέγχουμε τα βελάκια
        	switch(e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                if (direction != 'R') {
                    direction = 'L';
                }
                break;
            case KeyEvent.VK_RIGHT:
                if (direction != 'L') {
                    direction = 'R';
                }
                break;
            case KeyEvent.VK_UP:
                if (direction != 'D') {
                    direction = 'U';
                }
                break;
            case KeyEvent.VK_DOWN:
                if (direction != 'U') {
                    direction = 'D';
                }
                break;
        }
        }
    }
}
