package snake;

import javax.swing.JFrame;

public class GameFrame extends JFrame {
	GameFrame() {
        this.add(new GamePanel()); // Προσθέτουμε το πάνελ του παιχνιδιού
        this.setTitle("Snake Game - Java Edition");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack(); // Προσαρμόζει το παράθυρο στο μέγεθος του Panel
        this.setVisible(true);
        this.setLocationRelativeTo(null); // Εμφανίζεται στο κέντρο της οθόνης
    }
	
	public static void main(String[] args) {
        new GameFrame();
    }

}
